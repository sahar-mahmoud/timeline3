document.addEventListener('DOMContentLoaded', () => {
    const messagesDiv = document.getElementById('messages');
  
    async function loadMessages() {
      const response = await fetch('/messages');
      const messages = await response.json();
      messagesDiv.innerHTML = messages.map(message => `
        <div class="message">
          <p>${message.message}</p>
          <form class="postCommentForm" action="/comments" method="POST">
            <input type="hidden" name="message_id" value="${message._id}">
            <textarea name="comment" rows="2" placeholder="Write a comment..."></textarea>
            <button type="submit" class="btn">Post a Comment</button>
          </form>
          ${message.comments ? message.comments.map(comment => `
            <div class="comment">
              <p>${comment.comment}</p>
            </div>
          `).join('') : ''}
        </div>
      `).join('');
    }
  
    // استدعاء دالة تحميل الرسائل عند تحميل الصفحة
    loadMessages();
  });