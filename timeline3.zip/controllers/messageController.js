const Message = require('../models/Message');

exports.createMessage = async (req, res) => {
  const message = new Message({
    user_id: req.body.user_id,
    message: req.body.message
  });
  await message.save();
  res.redirect('/');
};

exports.getMessages = async (req, res) => {
  const messages = await Message.find().populate('user_id').exec();
  res.render('pages/index', { messages });
};