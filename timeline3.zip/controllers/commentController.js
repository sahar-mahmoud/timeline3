const Comment = require('../models/Comment');

exports.createComment = async (req, res) => {
  const comment = new Comment({
    message_id: req.body.message_id,
    comment: req.body.comment
  });
  await comment.save();
  res.redirect('/');
};